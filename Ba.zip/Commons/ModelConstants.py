class ModelConstants:
    
    BASE_CLUSTER = 'c1'
    DATABASE = 'jkfomo'
    
    # DB Collection
    DB_USERPROFILE = 'userprofile'
    