from marshmallow import Schema,fields

class DepartmentSchema(Schema):
    deptid = fields.Str(dump_only=True)
    name = fields.Str(required=True)

class DepartmentUpdateSchema(Schema):
    deptid = fields.Str(required=True)
    name = fields.Str(required=False)

class UserSchema(Schema):
    userid = fields.Str(dump_only=True)
    name = fields.Str(required=True)
    email = fields.Str(required=True)
    mobile = fields.Str(required=True)
    status = fields.Boolean(required=True)
    usertype = fields.Str(required=True)
    password = fields.Str(required=True)

class UserDeptSchema(UserSchema):
    depts = fields.List(fields.Nested(DepartmentUpdateSchema()))

