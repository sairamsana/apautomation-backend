from service.DepartmentService import blp as DeptBluePrint
from service.UserService import blp as UserBluePrint